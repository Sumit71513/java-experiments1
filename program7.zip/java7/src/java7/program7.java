package java7;

class MathOperation {
    
    int add(int a, int b) {
        return a + b;
    }
   
    int add(int a, int b, int c) {
        return a + b + c;
    }

    double add(double a, double b) {
        return a + b;
    }
}

public class program7{
    public static void main(String[] args) {
        MathOperation m = new MathOperation();

        System.out.println("Sum of 2 integers: " + m.add(10, 20));
        System.out.println("Sum of 3 integers: " + m.add(5, 15, 25));
        System.out.println("Sum of 2 doubles: " + m.add(3.5, 4.5));
    }
}
